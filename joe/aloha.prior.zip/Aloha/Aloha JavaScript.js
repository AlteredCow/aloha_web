// JavaScript Document
<a href="#" onclick="document.getElementById('the_div').style.display=(document.getElementById('the_div').style.display=='block')?'none':'block';">Show/Hide Div</a>