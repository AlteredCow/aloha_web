// Collapsable table contents.

function show(ID)
{
var element = document.getElementById(ID);
if(element.style.display == 'block') {element.style.display = 'none';}
else {element.style.display = 'block';}
} 